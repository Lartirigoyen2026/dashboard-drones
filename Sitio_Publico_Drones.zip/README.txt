DASHBOARD PUBLICO DE IMPORTACIONES DE DRONES

CONTENIDO
index.html: dashboard interactivo preparado para hosting estatico.

PUBLICAR EN GITHUB PAGES
1. Crear un repositorio publico nuevo en GitHub (ej. dashboard-drones).
2. Subir index.html en la raiz del repositorio.
3. Ir a Settings > Pages > Build and deployment.
4. Seleccionar Deploy from a branch, rama main, carpeta /(root), y guardar.
5. GitHub mostrara la URL publica del sitio tras completar el despliegue.

ACTUALIZACION MENSUAL
1. Subir el nuevo Excel COBUS en ChatGPT y solicitar regenerar el dashboard desde la solapa Detalle conservando el formato y los criterios.
2. Validar totales, duplicados, unidades y rango de fechas.
3. Reemplazar index.html en el mismo repositorio.
4. La URL publica no cambia.

IMPORTANTE: este archivo contiene datos de comercio exterior que seran visibles publicamente. Obtener aprobacion interna antes de publicar. Este paquete no incluye carga automatica de Excel desde la web ni autenticacion.
